print("Welcome to Band Name Generator.")
city = input("What's name of the city you grew up in?\n")
pet = input ("What is your pet name?\n")
print ("Your Band name could be " + city+' '+ pet)
